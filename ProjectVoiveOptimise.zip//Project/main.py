# -*- coding: utf-8 -*-


from modules.language_manager import LanguageManager
from modules.printer_control import PrinterControl
from modules.logger import logger

PRINTER_IP = "192.168.1.100"
PRINTER_PORT = "7125"

# Initialisation
lang_manager = LanguageManager(language="fr")
printer_control = PrinterControl(PRINTER_IP, PRINTER_PORT)

def main():
    logger.info("Démarrage de l'application")
    greeting = lang_manager.get_response("Greeting", "hello_with_vz")
    print(greeting)

    state = printer_control.get_printer_state()
    if state:
        logger.info(f"État de l'imprimante : {state}")
        print(lang_manager.get_response("Printer", "state").format(state=state))
    else:
        logger.error("Impossible de récupérer l'état de l'imprimante.")

if __name__ == "__main__":
    main()


