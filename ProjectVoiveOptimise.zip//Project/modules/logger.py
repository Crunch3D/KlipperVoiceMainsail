# -*- coding: utf-8 -*-


import logging

def setup_logger():
    """Configure le logger global."""
    logging.basicConfig(
        level=logging.INFO,
        format="%(asctime)s - %(levelname)s - %(message)s",
        handlers=[
            logging.FileHandler("app.log"),
            logging.StreamHandler()
        ]
    )
    return logging.getLogger("PrinterApp")

logger = setup_logger()


