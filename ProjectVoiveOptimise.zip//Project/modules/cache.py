# -*- coding: utf-8 -*-


import time

class Cache:
    def __init__(self):
        self.data = {}

    def set(self, key, value, ttl=60):
        """Stocke une valeur dans le cache avec un TTL (Time-To-Live)."""
        self.data[key] = {"value": value, "expires": time.time() + ttl}

    def get(self, key):
        """Récupère une valeur du cache si elle n'est pas expirée."""
        entry = self.data.get(key)
        if entry and time.time() < entry["expires"]:
            return entry["value"]
        return None
        
