# -*- coding: utf-8 -*-


import requests
from modules.cache import Cache

class PrinterControl:
    def __init__(self, printer_ip, printer_port):
        self.printer_ip = printer_ip
        self.printer_port = printer_port
        self.cache = Cache()

    def get_printer_state(self):
        """Récupère l'état actuel de l'imprimante avec mise en cache."""
        cached_state = self.cache.get("printer_state")
        if cached_state:
            return cached_state

        try:
            response = requests.get(f"http://{self.printer_ip}:{self.printer_port}/printer/objects/query?print_stats", timeout=5)
            if response.status_code == 200:
                state = response.json()["result"]["status"]["print_stats"]["state"]
                self.cache.set("printer_state", state, ttl=10)
                return state
        except Exception as e:
            print(f"Erreur lors de la récupération de l'état de l'imprimante : {e}")
        return None

    def check_file_exists(self, filename):
        """Vérifie si un fichier existe sur l'imprimante."""
        cached_files = self.cache.get("printer_files")
        if cached_files:
            return filename in cached_files

        try:
            response = requests.get(f"http://{self.printer_ip}:{self.printer_port}/server/files/list?root=gcodes", timeout=5)
            if response.status_code == 200:
                files = [file["filename"] for file in response.json()["result"] if isinstance(file, dict)]
                self.cache.set("printer_files", files, ttl=60)
                return filename in files
        except Exception as e:
            print(f"Erreur lors de la vérification des fichiers : {e}")
        return False
        
