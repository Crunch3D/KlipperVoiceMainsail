# -*- coding: utf-8 -*-


import configparser
import os

class LanguageManager:
    def __init__(self, language="en", config_dir="config"):
        self.language = language
        self.config_dir = config_dir
        self.messages = {}
        self.load_language_file()

    def load_language_file(self):
        """Charge le fichier de langue correspondant."""
        filepath = os.path.join(self.config_dir, f"responses_{self.language}.ini")
        if not os.path.exists(filepath):
            print(f"Fichier de langue introuvable : {filepath}, fallback sur anglais.")
            filepath = os.path.join(self.config_dir, "responses_en.ini")
        
        config = configparser.ConfigParser()
        config.read(filepath)
        self.messages = {section: dict(config.items(section)) for section in config.sections()}

    def get_response(self, section, key):
        """Récupère un message depuis le fichier INI."""
        return self.messages.get(section, {}).get(key, f"Erreur : clé {key} manquante dans {section}")

