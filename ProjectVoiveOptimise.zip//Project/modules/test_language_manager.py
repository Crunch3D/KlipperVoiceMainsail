# -*- coding: utf-8 -*-


from modules.language_manager import LanguageManager

def test_language_manager_fallback():
    lang_manager = LanguageManager(language="unknown")
    response = lang_manager.get_response("Greeting", "hello_with_vz")
    assert "Erreur" not in response  # Vérifie que le fallback fonctionne
    
